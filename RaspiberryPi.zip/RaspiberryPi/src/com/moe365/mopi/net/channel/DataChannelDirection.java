package com.moe365.mopi.net.channel;

public enum DataChannelDirection {
	DEFAULT,
	SERVER_TO_CLIENT,
	CLIENT_TO_SERVER,
	BOTH;
}
